Submission format v1. The metadata uses Red Hat as an example; replace it with your configuration.
Choose <submitter>-<YYYY-MM-DD>-<harness>-<model>[-<variant>] as your submission ID.
Use the UTC date the PR is first submitted; keep the ID stable during review.
Use lowercase letters, digits, hyphens, and dots; add a variant only when needed.
Replace the placeholder prompt.txt with your exact prompt template.
Add original files under trajectories/<task-id>/<run-id>/ for every task and declared run.
Keep failures and diagnostic files. Do not create predictions or scores.
Maintainers use the benchmark repository's validation, parsing, and scoring tools; the website integrates accepted results.
Processed predictions.jsonl, reference_metrics.json, and processing.json go in data/submissions/<submitter-id>/<submission-id>/. Submitters do not create these.
Each processing.json identifies the matching upload, records input/output hashes, and includes source attribution. Only uploads with processed packages appear on the leaderboard.
Prepare metadata.json, prompt.txt, and trajectories/ under data/uploads/<submitter-id>/<submission-id>/.
The parent folder must match metadata.submitter.id; reuse it for your team's submissions.
Rename both example folders to match your submitter ID and metadata.id.
Website repository: https://github.com/vex-bench/vex-bench.github.io
Contact maintainers through a repository issue before sending raw artifacts.
The repository ignores trajectories/; original files remain required for processing, but external storage/delivery is not implemented. Do not force-add large logs.
This ZIP is a starter, not a submission. Read FORMAT.md for the proposed contract.
Native processing of this layout and automatic PR processing are not enabled yet.
