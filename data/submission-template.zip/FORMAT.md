# Submit evaluation results

Prepare results under `data/uploads/<submitter-id>/<submission-id>/` for a PR to
[vex-bench/vex-bench.github.io](https://github.com/vex-bench/vex-bench.github.io),
after coordinating original artifact delivery with the maintainers as described below.
The submitter folder groups a team's submissions; each submission folder
represents one model/harness configuration. A PR may contain several configurations.

The incoming format is version **1**. It contains metadata, the prompt, and
original run files. Maintainers use the benchmark repository's tools to
validate submissions, derive predictions, and calculate scores. The website
receives submissions and displays accepted, processed results.

## Current implementation and artifact delivery

This is the **proposed format**, not an automated submission service. Native
packaging/processing for this layout and automatic PR processing remain pending.
Contact the maintainers through a [website-repository issue](https://github.com/vex-bench/vex-bench.github.io/issues)
before sending original artifacts. External trajectory storage and delivery
have not been implemented.

The layout below describes the complete processing input. The repository
currently versions metadata, prompts, and accepted processed packages, while
`.gitignore` deliberately excludes `trajectories/` and local source archives.
Original files remain required for processing, but are not included in a normal
Git checkout or deployed website. Do not remove the ignore rules or force-add
large logs to work around the pending delivery design.

## Directory layout

```text
data/uploads/
└── redhat/
    └── redhat-2026-10-05-cursor-grok-4.6/
        ├── metadata.json
        ├── prompt.txt
        └── trajectories/                 # Original files, retained locally
            ├── alibaba-nacos-20caf99-CVE-2025-55752/
            │   ├── run_001/result.json
            │   ├── run_002/result.json
            │   └── run_003/result.json
            └── <every-other-task-id>/
                └── <each-declared-run-id>/
                    └── original outputs, errors, and available logs
```

Prepare the expanded layout rather than a ZIP as the format itself. Preserve
original filenames and subdirectories inside each run. The downloadable ZIP
contains starter files only; replace its example metadata and placeholder prompt.

The submitter folder must match `metadata.json`'s `submitter.id` exactly.
Use a stable lowercase team slug such as `redhat` and reuse that folder for
later submissions. Each submission folder must match `metadata.json`'s `id`.

## Submission ID

Use this naming convention for new submissions:

```text
<submitter>-<YYYY-MM-DD>-<harness>-<model>[-<variant>]
```

For example:

```text
redhat-2026-10-05-codex-gpt-5.5
redhat-2026-10-05-codex-gpt-5.5-high
redhat-2026-10-05-claude-claude-sonnet-4.6
```

- Use the submitter's stable team ID, the date the PR is first submitted
  (UTC), and readable harness/model identifiers. If `submission_date` is set,
  it must match that date. This is not the experiment or packaging date.
- Use lowercase letters, digits, hyphens, and dots. Keep dots in version
  numbers; convert spaces, underscores, slashes, and other separators to
  hyphens. Start and end the complete ID with a letter or digit.
- The folder name and `metadata.json`'s `id` must match exactly. The ID must
  be unique across incoming and accepted submissions.
- Add a short variant only when needed to distinguish configurations, such
  as `high`, `custom-prompt`, or `2`. The full settings still belong in metadata.
- Keep the ID stable when correcting the same PR, even if the review spans
  several days. Use a new ID for a separate submission.

The ID is a readable unique name; parsers use the metadata to identify the
configuration rather than inferring settings from the name. Exact model and
harness identifiers remain unchanged in metadata.
The submitter prefix remains part of the submission ID so the ID is also
unique when accepted entries are stored outside their submitter folder.

## `metadata.json`

This example describes the active Red Hat Cursor / Grok 4.6 configuration.
Its settings and harness version were not recorded, so they remain unknown.
It contains final outputs only; do not label these records as interaction traces.
The historical date was supplied by the maintainer.

```json
{
  "schema_version": 1,
  "id": "redhat-2026-10-05-cursor-grok-4.6",
  "submitter": {
    "id": "redhat",
    "name": "Red Hat"
  },
  "dataset": {
    "id": "vex-bench",
    "version": "2026-05"
  },
  "model": {
    "id": "grok-4.6",
    "name": "Grok 4.6",
    "provider": "xAI",
    "settings": {}
  },
  "harness": {
    "id": "cursor",
    "name": "Cursor",
    "version": null,
    "settings": {}
  },
  "access_provider": null,
  "protocol": null,
  "run_ids": [
    "run_001",
    "run_002",
    "run_003"
  ],
  "settings": {
    "timeout_seconds": null
  },
  "artifacts": {
    "format": "cursor-local-isolated-json",
    "content": "final-output-only"
  },
  "submission_date": "2026-10-05"
}
```

| Field | Requirement |
| --- | --- |
| `schema_version` | Required; integer `1`. |
| `id` | Required; follows the submission ID convention above, matches the enclosing folder, and is unique across uploads and accepted submissions. |
| `submitter.id`, `submitter.name` | Required; stable team identifier matching the parent submitter folder, and display name. |
| `dataset.id`, `dataset.version` | Required; `vex-bench` and an exact published release, such as `2026-05`. |
| `model.id` | Required; exact model identifier used for this configuration. |
| `harness.id` | Required; harness identifier used to select the result parser. |
| `run_ids` | Required; nonempty list of unique run directory names. Preserve original run IDs. |
| `artifacts.format` | Required; the original output format, from the table below. |
| `artifacts.content` | Required; describes what was actually recorded, from the table below. |
| `model.name`, `model.provider`, `harness.name` | Optional display information. If omitted, identifiers can be displayed. |
| `harness.version` | Optional; exact recorded version, or `null` if unknown. |
| `model.settings`, `harness.settings`, `settings` | Optional objects containing recorded settings, such as reasoning effort, enabled tools, and timeout. Omit unknown settings or use `null`; `{}` means no settings were recorded. |
| `access_provider` | Optional; service used to access the model, such as `Vertex AI`, or `null`. Separate from the model developer and harness. |
| `protocol` | Optional; known benchmark protocol identifier, or `null`. A matching dataset alone does not establish protocol equivalence. |
| `submission_date` | Optional; actual submission date as `YYYY-MM-DD`, or `null`. Never substitute the packaging/build date. |
| `cost_basis` | Optional; the recorded pricing basis for a cost estimate, or `null`. Historical paper estimates retain their original basis. |

Submission IDs, submitter IDs, task IDs, and run IDs must be single path
components: no `/`, `\\`, `.` or `..` components. Model identifiers remain
metadata and may include provider prefixes. Unknown values must not be guessed. Configurations that
use different prompts, models, harness versions, or execution settings belong
in separate submission folders. Repeated runs share the same configuration.

## `prompt.txt`

Include the exact prompt template used for this configuration, preserving its
text and placeholders. Task-specific substitutions come from the referenced
dataset. Preserve any recorded additional instructions or per-task expanded
prompts with the corresponding run's artifacts.

Different prompt templates require separate configurations. The processing
pipeline computes prompt fingerprints; users do not need to write them.

## `trajectories/<task-id>/<run-id>/`

Include every task in the selected release for every declared run, exactly
once. Use the task IDs from the release's
[`tasks.jsonl`](../benchmarks/2026-05/tasks.jsonl), rather than CVE IDs alone:
one CVE can occur in several tasks.

For release `2026-05`, there are 75 tasks. Three declared runs therefore require
225 task/run directories per configuration. Three runs describe the Red Hat
example; this format does not introduce a new minimum repeat count.

Keep original outputs and all available interaction logs, tool records, and
auxiliary artifacts. No common trajectory event format is required.

The existing Red Hat ingestion adapters recognize these formats:

| `harness.id` | `artifacts.format` | Original result filename | `artifacts.content` |
| --- | --- | --- | --- |
| `codex` | `codex-jsonl` | `result.jsonl` | `recorded-events` |
| `claude` | `claude-code-jsonl` | `result.jsonl` | `recorded-events` |
| `vertex_claude_code` | `claude-code-jsonl` | `result.jsonl` | `recorded-events` |
| `opencode` | `opencode-session-json` | `result.json`, plus available `artifacts/` | `session-export-and-logs` |
| `opencode` | `opencode-jsonl-or-session-json` | Historical `result.jsonl` and/or `result.json`, with available `artifacts/` | `session-export-and-logs` |
| `cursor` | `cursor-local-isolated-json` | `result.json` containing an `output` string | `final-output-only` |

`recorded-events` means the recorded interaction events; `session-export-and-logs`
means the session export and its available diagnostic files; `final-output-only`
means no interaction trace was supplied. Declare the limitation explicitly when
only a final output is available. Model access through Vertex AI should also be
recorded as `access_provider: "Vertex AI"` when known.

Other harnesses or formats need a matching parser before scoring. Preserve their
original files and identify the format in the PR rather than disguising them
as a supported harness.

### Failures

Do not drop timeouts, crashes, invalid answers, or runs that produced no result.
Keep partial output and original error/diagnostic files in the same task/run
directory. If there is no result or diagnostic file, include `error.txt` stating
the recorded failure; use `No result recorded; cause unknown.` if no cause was
recorded. This preserves the failed attempt in the processing input. Do not
manufacture an answer for a failed run.

Every task/run directory must contain at least one result or error/diagnostic
file. The parser determines whether an answer can be extracted; the submitter
does not need to assign parsing statuses.

## What belongs to processing

Users do not need to submit predictions, ground-truth labels, aggregate metrics,
checksums, a file inventory, or a batch `upload.json`. The receiver generates the
inventory and provenance records from the submitted files. Include raw logged
usage when available; unknown usage and cost remain unknown.

## Existing results

There are nine original-paper uploads under
[`original-paper/`](original-paper/) and four active Red Hat Cursor uploads under
[`redhat/`](redhat/). The four Cursor configurations contain 900 task/run records:
896 parsed answers and four parsing failures. Unknown usage and costs remain
unknown; all four are explicitly marked `final-output-only`.

Paper results preserve their recorded predictions and metrics across three
evaluation runs, numbered 001, 002, and 003. Paper submission dates use
`2026-05-25` by maintainer convention. Red Hat dates use the supplied `2026-10-05`.
Historical imported dates are not evidence of a PR on that date.

Original task/run files are retained locally, outside Git. Nine overlapping
Red Hat configurations and the original batch copies are deferred in the
ignored `data/deferred-results/` archive and are not build inputs.

## Processed result package

After benchmark processing, maintainers integrate a separate result package:

```text
data/submissions/<submitter-id>/<submission-id>/
├── predictions.jsonl
├── reference_metrics.json
└── processing.json
```

Configuration metadata, prompts, and locally retained original files stay in
the matching upload folder. Submitters do not need to produce predictions,
metrics, or receipts. See the [processed result format](../submissions/README.md)
for the stored records, receipt checks, and active example.

The static build validates and displays these stored packages without an
evaluator checkout or raw trajectories. An upload alone does not score results
or create a leaderboard entry. The legacy parse/score scripts require a separate
internal staging layout; they are not direct processing commands for this format.
